(function() {
  "use strict";
  return {
    initialize: function() {
      if(page_type == "ticket") {
          if (jQuery('.author-mail-detail:first:contains("Created by")').length > 0) {
              var firstDivAuthorDetail = jQuery('.author-mail-detail:first').find('div:first').remove();
              var lastDivAuthorDetail = jQuery('.author-mail-detail:first').find('.info').remove();

              jQuery('.author-mail-detail:first').empty();

              jQuery('.author-mail-detail:first').append(firstDivAuthorDetail);
              jQuery('.author-mail-detail:first').append(lastDivAuthorDetail);
          }

      }
    }
  };
})();
