(function() {
  "use strict";
  return {
    initialize: function() {
        if(page_type == "ticket") {

            var reverseOrderBox = document.createElement('div');
            reverseOrderBox.id = 'reverse_ticket_replies_order';

            jQuery('#reverse_ticket_replies_order').closest('.widget').removeClass('widget');

            jQuery(document).on("ticket_view_loaded",function(){
                jQuery('.redactor').insertAfter('#original_request');

            });



            function changeOrder(id_value){
                var ID = [];
                jQuery('#' + id_value).find(".conversation").each(function(){
                        ID.push(jQuery(this).attr('data-timestamp'));
                    });

                ID = ID.sort().reverse();

                jQuery(ID).each(function(i,item){
                    jQuery('#' + id_value).append(jQuery('[data-timestamp=' + item + ']'));
                });
            }


            function reorderNotes(){
                if(jQuery('#all_notes').length) {
                    var id_value = "all_notes";
                    changeOrder(id_value);
                }

                else {
                    var id_value = "all_activities";
                    changeOrder(id_value);
                }
            }


            jQuery('#Pagearea').ajaxComplete(function(){
                reorderNotes();
            });

      }
    }
  };
})();
