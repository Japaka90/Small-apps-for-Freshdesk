(function() {
  "use strict";
  return {
    initialize: function() {
        if(page_type == "ticket") {
            var appSendBtn = document.createElement('div');
            appSendBtn.id = 'add_btn_send_resolve_in_reply';        

            jQuery(document).ready(function() {
                if(jQuery('body').hasClass('ticket_details')) {
                    var buttonLabel = 'Send and Resolve';

                    //Adding the new button
                    jQuery('#HelpdeskReply .btn-toolbar>span:last').before('<span class="btn-group"><button class="btn"'+
                    ' rel="custom-reply-status" data-cnt-id="cnt-reply" data-status-val="4">' + buttonLabel +
                    '</button></span>');

                    //Moving the Save Draft to the left side.
                    jQuery('#reply-draft').detach().appendTo('.post_in_forum');
                    jQuery('#add_btn_send_resolve_in_reply').parent().parent().remove();
                }
            });
        }
    }
  };
})();
