(function() {
  "use strict";
  return {
    initialize: function() {
      if(page_type == "ticket") {
        var type = {
            '...' : '#ffffff',
            'Open' : '#de0000',
            'Pending' : '#008ff9',
            'Resolved' : '#ffb613',
            'Closed' : '#7ebf00',
            'Waiting on Customer' : '#ffdae0',
            'Väntar på svar från anläggning' : '#ffdae0',
            'Väntar på svar från leverantör' : '#dbc7f9',
            'Väntar på svar internt' : '#db9bd1',
            'Åtgärdas senare' : '#a8f4f7'
        };

        jQuery('#coloured_ticket_types').closest('.widget').removeClass('widget');

        var checkDom = setInterval(function() {
            if (jQuery('#s2id_helpdesk_ticket_status').length > 0) {
                ticketTypeColorChange();
                clearInterval(checkDom);
            }
        }, 500);

        function ticketTypeColorChange() {
            var selected = jQuery('#s2id_helpdesk_ticket_status').find('.select2-chosen').text();
            var index_value = type[selected];
            jQuery("#s2id_helpdesk_ticket_status a").css('background', index_value);
        }

        jQuery(document).on('change', '#helpdesk_ticket_status', ticketTypeColorChange);

      }
    }
  };
})();
